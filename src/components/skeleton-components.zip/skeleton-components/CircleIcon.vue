<template>
  <div class="circle-icon"></div>
</template>

<style>
.circle-icon {
  height: 36px;
  width: 36px;
  border: 1px solid yellowgreen;
  border-radius: 36px;
  background-color: rgb(187, 59, 59);
}
</style>