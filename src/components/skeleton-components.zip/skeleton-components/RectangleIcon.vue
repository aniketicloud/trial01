<template>
  <div class="rectangleIcon"></div>
</template>

<style>
.rectangleIcon {
  height: 14px;
  width: 50px;
  border: 1px solid yellowgreen;
  border-radius: 5px;
  background-color: rgb(48, 125, 148);
}
</style>