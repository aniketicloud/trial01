<template>
    <div>
        <single-row></single-row>
        <single-row></single-row>
    </div>
</template>

<script>
import SingleRow from './SingleRow'
export default {
    components:{
        SingleRow
    }
}
</script>