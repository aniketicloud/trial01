<template>
  <div class="square-icon"></div>
</template>

<style>
.square-icon {
  height: 24px;
  width: 24px;
  border: 1px solid yellowgreen;
  border-radius: 5px;
  background-color: rgb(187, 59, 59);
}
</style>