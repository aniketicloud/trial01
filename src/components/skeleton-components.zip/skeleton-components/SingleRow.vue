<template>
  <div class="line"></div>
</template>

<style>
.line {
  height: 25px;
  border: 1px solid yellowgreen;
  border-radius: 5px;
  background-color: red;
}
</style>