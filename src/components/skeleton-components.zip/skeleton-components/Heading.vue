<template>
<div class="rectangle">
</div>
</template>

<style>
.rectangle{
  height: 42px;
  border: 1px solid yellowgreen;
  border-radius: 5px;
  background-color: blueviolet;
}

</style>